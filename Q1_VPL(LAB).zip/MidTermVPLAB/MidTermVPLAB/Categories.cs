﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidTermVPLAB
{
    public partial class Categories : Form
    {
        public Categories()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (btnReligion.Checked == true)
                {
                RelQuiz relquizqz = new RelQuiz();
                relquizqz.Show();
                this.Hide();
                this.Close();
                }
            else if (btnGK.Checked == true)
            {
                GkQuiz gkquiz = new GkQuiz();
                gkquiz.Show();
                this.Hide();
                this.Close();
            }
            else if (btnIQ.Checked == true)
            {
                IQuiz iquiz = new IQuiz();
                iquiz.Show();
                this.Hide();
                this.Close();
            }
            else
            {
                MessageBox.Show("You have not select any Button","Select Please",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }
    }
}
