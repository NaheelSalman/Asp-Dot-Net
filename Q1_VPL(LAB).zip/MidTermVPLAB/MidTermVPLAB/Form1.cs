﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidTermVPLAB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        string Username;
        string email;
        string pass;
        private void txtUsername_Validating(object sender, CancelEventArgs e)
        {
            Regex rg_uname = new Regex(@"^[a-zA-Z0-9]{4,}$");
            if (!rg_uname.IsMatch(txtUsername.Text))
            {
                errormsg.SetError(txtUsername, "invalid input");
            }
            else
            {
                errormsg.Clear();
            }
        }

        private void txtMail_Validating(object sender, CancelEventArgs e)
        {
            Regex rg_email = new Regex(@"^[\w_\.]+@[a-z]{2,7}\.[a-z]{2,3}$");
            if (!rg_email.IsMatch(txtMail.Text))
            {
                errormsg.SetError(txtMail, "invalid input");
            }
            else
            {
                errormsg.Clear();
            }
        }

        private void txtPass_Validating(object sender, CancelEventArgs e)
        {
            Regex rg_pass = new Regex(@"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$");
            if (!rg_pass.IsMatch(txtPass.Text))
            {
                errormsg.SetError(txtPass, "min 8 char, one Upper one lower");
            }
            else
            {
                errormsg.Clear();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text== "Admin")
            {
                int id = 1;
                con.Open();
                cmd = new SqlCommand("Select username,email,password from users where user_Id=@ID", con);
                cmd.Parameters.AddWithValue("@ID", id);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Username = dr.GetValue(0).ToString();
                    email = dr.GetValue(1).ToString();
                    pass = dr.GetValue(2).ToString();


                 }
                if (txtUsername.Text == Username && txtMail.Text == email && txtPass.Text == pass)
                {
                    Admin admin = new Admin();
                    admin.Show();
                    this.Hide();
                }


                con.Close();
            }
            else if (comboBox1.Text == "User")
            {
                int id = 2;
                con.Open();
                cmd = new SqlCommand("Select username,email,password from users where user_Id=@ID", con);
                cmd.Parameters.AddWithValue("@ID", id);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Username = dr.GetValue(0).ToString();
                    email = dr.GetValue(1).ToString();
                    pass = dr.GetValue(2).ToString();


                }
                if (txtUsername.Text == Username && txtMail.Text == email && txtPass.Text == pass)
                {
                    Categories cs = new Categories();
                    cs.Show();
                    this.Hide();
                }
                con.Close();
            }
           
            
            //else if (txtUsername.Text == "Admin" && txtMail.Text == "" && txtPass.Text == "")
            //{
            //    Admin admin = new Admin();
            //    admin.Show();
            //    this.Hide();
            //}
            //else if (txtUsername.Text == "User" && txtMail.Text == "" && txtPass.Text == "")
            //{
            //    Categories cs = new Categories();
            //    cs.Show();
            //    this.Hide();
            //}

            else
            {
                MessageBox.Show("Check Your Mail and Pass again","Wrong Email/Username/Pass",MessageBoxButtons.OK,MessageBoxIcon.Error );
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=DESKTOP-B1M1BAQ\SQLEXPRESS;Initial Catalog=quizdb;Integrated Security=True");
        }
    }
}
