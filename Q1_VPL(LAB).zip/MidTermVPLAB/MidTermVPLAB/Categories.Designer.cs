﻿namespace MidTermVPLAB
{
    partial class Categories
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnReligion = new System.Windows.Forms.RadioButton();
            this.btnGK = new System.Windows.Forms.RadioButton();
            this.btnIQ = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(102, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Choose Category";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(155, 333);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnReligion
            // 
            this.btnReligion.AutoSize = true;
            this.btnReligion.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReligion.Location = new System.Drawing.Point(55, 132);
            this.btnReligion.Name = "btnReligion";
            this.btnReligion.Size = new System.Drawing.Size(109, 27);
            this.btnReligion.TabIndex = 5;
            this.btnReligion.TabStop = true;
            this.btnReligion.Text = "Religious";
            this.btnReligion.UseVisualStyleBackColor = true;
            // 
            // btnGK
            // 
            this.btnGK.AutoSize = true;
            this.btnGK.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGK.Location = new System.Drawing.Point(55, 195);
            this.btnGK.Name = "btnGK";
            this.btnGK.Size = new System.Drawing.Size(199, 27);
            this.btnGK.TabIndex = 6;
            this.btnGK.TabStop = true;
            this.btnGK.Text = "General KnowLedge";
            this.btnGK.UseVisualStyleBackColor = true;
            // 
            // btnIQ
            // 
            this.btnIQ.AutoSize = true;
            this.btnIQ.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIQ.Location = new System.Drawing.Point(55, 261);
            this.btnIQ.Name = "btnIQ";
            this.btnIQ.Size = new System.Drawing.Size(49, 27);
            this.btnIQ.TabIndex = 7;
            this.btnIQ.TabStop = true;
            this.btnIQ.Text = "IQ";
            this.btnIQ.UseVisualStyleBackColor = true;
            // 
            // Categories
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MidTermVPLAB.Properties.Resources.bridge_lake_bokeh_hd_wallpaper;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(436, 450);
            this.Controls.Add(this.btnIQ);
            this.Controls.Add(this.btnGK);
            this.Controls.Add(this.btnReligion);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Categories";
            this.Text = "Categories";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton btnReligion;
        private System.Windows.Forms.RadioButton btnGK;
        private System.Windows.Forms.RadioButton btnIQ;
    }
}