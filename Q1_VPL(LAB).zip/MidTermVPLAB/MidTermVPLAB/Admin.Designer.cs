﻿namespace MidTermVPLAB
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtquestion = new System.Windows.Forms.TextBox();
            this.txtchoices = new System.Windows.Forms.TextBox();
            this.txtanswer = new System.Windows.Forms.TextBox();
            this.txtcategory_Id = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.question = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.choice_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.choice_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.choice_3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.choice_4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.answer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.category_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quizquestionsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.quizdbDataSet2 = new MidTermVPLAB.quizdbDataSet2();
            this.quizquestionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.quizdbDataSet = new MidTermVPLAB.quizdbDataSet();
            this.quiz_questionsTableAdapter = new MidTermVPLAB.quizdbDataSetTableAdapters.Quiz_questionsTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtchoice_2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtchoice_3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtchoice_4 = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnedit = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.quiz_questionsTableAdapter1 = new MidTermVPLAB.quizdbDataSet2TableAdapters.Quiz_questionsTableAdapter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.questionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.choice1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.choice2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.choice3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.choice4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.answerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quizquestionsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quizdbDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quizquestionsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quizdbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtId
            // 
            this.txtId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtId.Location = new System.Drawing.Point(672, 53);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(111, 26);
            this.txtId.TabIndex = 0;
            // 
            // txtquestion
            // 
            this.txtquestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtquestion.Location = new System.Drawing.Point(672, 91);
            this.txtquestion.Multiline = true;
            this.txtquestion.Name = "txtquestion";
            this.txtquestion.Size = new System.Drawing.Size(176, 38);
            this.txtquestion.TabIndex = 1;
            // 
            // txtchoices
            // 
            this.txtchoices.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtchoices.Location = new System.Drawing.Point(672, 151);
            this.txtchoices.Multiline = true;
            this.txtchoices.Name = "txtchoices";
            this.txtchoices.Size = new System.Drawing.Size(176, 32);
            this.txtchoices.TabIndex = 2;
            // 
            // txtanswer
            // 
            this.txtanswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtanswer.Location = new System.Drawing.Point(672, 325);
            this.txtanswer.Multiline = true;
            this.txtanswer.Name = "txtanswer";
            this.txtanswer.Size = new System.Drawing.Size(111, 20);
            this.txtanswer.TabIndex = 3;
            this.txtanswer.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // txtcategory_Id
            // 
            this.txtcategory_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtcategory_Id.Location = new System.Drawing.Point(672, 373);
            this.txtcategory_Id.Name = "txtcategory_Id";
            this.txtcategory_Id.Size = new System.Drawing.Size(111, 26);
            this.txtcategory_Id.TabIndex = 4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.question,
            this.choice_1,
            this.choice_2,
            this.choice_3,
            this.choice_4,
            this.answer,
            this.category_id,
            this.idDataGridViewTextBoxColumn,
            this.questionDataGridViewTextBoxColumn,
            this.choice1DataGridViewTextBoxColumn,
            this.choice2DataGridViewTextBoxColumn,
            this.choice3DataGridViewTextBoxColumn,
            this.choice4DataGridViewTextBoxColumn,
            this.answerDataGridViewTextBoxColumn,
            this.categoryidDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.quizquestionsBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(12, 54);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(545, 339);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Id
            // 
            this.Id.DataPropertyName = "Id";
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            // 
            // question
            // 
            this.question.DataPropertyName = "question";
            this.question.HeaderText = "question";
            this.question.Name = "question";
            // 
            // choice_1
            // 
            this.choice_1.DataPropertyName = "choice_1";
            this.choice_1.HeaderText = "choice_1";
            this.choice_1.Name = "choice_1";
            // 
            // choice_2
            // 
            this.choice_2.DataPropertyName = "choice_2";
            this.choice_2.HeaderText = "choice_2";
            this.choice_2.Name = "choice_2";
            // 
            // choice_3
            // 
            this.choice_3.DataPropertyName = "choice_3";
            this.choice_3.HeaderText = "choice_3";
            this.choice_3.Name = "choice_3";
            // 
            // choice_4
            // 
            this.choice_4.DataPropertyName = "choice_4";
            this.choice_4.HeaderText = "choice_4";
            this.choice_4.Name = "choice_4";
            // 
            // answer
            // 
            this.answer.DataPropertyName = "answer";
            this.answer.HeaderText = "answer";
            this.answer.Name = "answer";
            // 
            // category_id
            // 
            this.category_id.DataPropertyName = "category_id";
            this.category_id.HeaderText = "category_id";
            this.category_id.Name = "category_id";
            // 
            // quizquestionsBindingSource1
            // 
            this.quizquestionsBindingSource1.DataMember = "Quiz_questions";
            this.quizquestionsBindingSource1.DataSource = this.quizdbDataSet2;
            // 
            // quizdbDataSet2
            // 
            this.quizdbDataSet2.DataSetName = "quizdbDataSet2";
            this.quizdbDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // quizquestionsBindingSource
            // 
            this.quizquestionsBindingSource.DataMember = "Quiz_questions";
            this.quizquestionsBindingSource.DataSource = this.quizdbDataSet;
            // 
            // quizdbDataSet
            // 
            this.quizdbDataSet.DataSetName = "quizdbDataSet";
            this.quizdbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // quiz_questionsTableAdapter
            // 
            this.quiz_questionsTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F);
            this.label1.Location = new System.Drawing.Point(238, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(333, 36);
            this.label1.TabIndex = 10;
            this.label1.Text = "Add/Maintain Questions";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(577, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "Question ID";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(577, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "Question";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(577, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "Choices";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(577, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "Answer";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(577, 373);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "Category ID";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(577, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 20);
            this.label7.TabIndex = 17;
            this.label7.Text = "Choices";
            // 
            // txtchoice_2
            // 
            this.txtchoice_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtchoice_2.Location = new System.Drawing.Point(672, 189);
            this.txtchoice_2.Multiline = true;
            this.txtchoice_2.Name = "txtchoice_2";
            this.txtchoice_2.Size = new System.Drawing.Size(176, 32);
            this.txtchoice_2.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label8.Location = new System.Drawing.Point(577, 239);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 20);
            this.label8.TabIndex = 19;
            this.label8.Text = "Choices";
            // 
            // txtchoice_3
            // 
            this.txtchoice_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtchoice_3.Location = new System.Drawing.Point(672, 227);
            this.txtchoice_3.Multiline = true;
            this.txtchoice_3.Name = "txtchoice_3";
            this.txtchoice_3.Size = new System.Drawing.Size(176, 32);
            this.txtchoice_3.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(577, 277);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 20);
            this.label9.TabIndex = 21;
            this.label9.Text = "Choices";
            // 
            // txtchoice_4
            // 
            this.txtchoice_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtchoice_4.Location = new System.Drawing.Point(672, 265);
            this.txtchoice_4.Multiline = true;
            this.txtchoice_4.Name = "txtchoice_4";
            this.txtchoice_4.Size = new System.Drawing.Size(176, 32);
            this.txtchoice_4.TabIndex = 20;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImage = global::MidTermVPLAB.Properties.Resources._1116032_preview_preview;
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDelete.Location = new System.Drawing.Point(773, 420);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 48);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnedit
            // 
            this.btnedit.BackgroundImage = global::MidTermVPLAB.Properties.Resources.download1;
            this.btnedit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnedit.Location = new System.Drawing.Point(672, 420);
            this.btnedit.Name = "btnedit";
            this.btnedit.Size = new System.Drawing.Size(75, 48);
            this.btnedit.TabIndex = 8;
            this.btnedit.UseVisualStyleBackColor = true;
            this.btnedit.Click += new System.EventHandler(this.btnedit_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::MidTermVPLAB.Properties.Resources._221_2214644_button_add_icon_web_symbol_internet_website_add;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Location = new System.Drawing.Point(557, 420);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 48);
            this.button2.TabIndex = 7;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::MidTermVPLAB.Properties.Resources.download;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(12, 420);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 48);
            this.button1.TabIndex = 6;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // quiz_questionsTableAdapter1
            // 
            this.quiz_questionsTableAdapter1.ClearBeforeFill = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::MidTermVPLAB.Properties.Resources.download__1_;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(9, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(59, 47);
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.btnBack);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // questionDataGridViewTextBoxColumn
            // 
            this.questionDataGridViewTextBoxColumn.DataPropertyName = "question";
            this.questionDataGridViewTextBoxColumn.HeaderText = "question";
            this.questionDataGridViewTextBoxColumn.Name = "questionDataGridViewTextBoxColumn";
            // 
            // choice1DataGridViewTextBoxColumn
            // 
            this.choice1DataGridViewTextBoxColumn.DataPropertyName = "choice_1";
            this.choice1DataGridViewTextBoxColumn.HeaderText = "choice_1";
            this.choice1DataGridViewTextBoxColumn.Name = "choice1DataGridViewTextBoxColumn";
            // 
            // choice2DataGridViewTextBoxColumn
            // 
            this.choice2DataGridViewTextBoxColumn.DataPropertyName = "choice_2";
            this.choice2DataGridViewTextBoxColumn.HeaderText = "choice_2";
            this.choice2DataGridViewTextBoxColumn.Name = "choice2DataGridViewTextBoxColumn";
            // 
            // choice3DataGridViewTextBoxColumn
            // 
            this.choice3DataGridViewTextBoxColumn.DataPropertyName = "choice_3";
            this.choice3DataGridViewTextBoxColumn.HeaderText = "choice_3";
            this.choice3DataGridViewTextBoxColumn.Name = "choice3DataGridViewTextBoxColumn";
            // 
            // choice4DataGridViewTextBoxColumn
            // 
            this.choice4DataGridViewTextBoxColumn.DataPropertyName = "choice_4";
            this.choice4DataGridViewTextBoxColumn.HeaderText = "choice_4";
            this.choice4DataGridViewTextBoxColumn.Name = "choice4DataGridViewTextBoxColumn";
            // 
            // answerDataGridViewTextBoxColumn
            // 
            this.answerDataGridViewTextBoxColumn.DataPropertyName = "answer";
            this.answerDataGridViewTextBoxColumn.HeaderText = "answer";
            this.answerDataGridViewTextBoxColumn.Name = "answerDataGridViewTextBoxColumn";
            // 
            // categoryidDataGridViewTextBoxColumn
            // 
            this.categoryidDataGridViewTextBoxColumn.DataPropertyName = "category_id";
            this.categoryidDataGridViewTextBoxColumn.HeaderText = "category_id";
            this.categoryidDataGridViewTextBoxColumn.Name = "categoryidDataGridViewTextBoxColumn";
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MidTermVPLAB.Properties.Resources.Background1;
            this.ClientSize = new System.Drawing.Size(852, 480);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtchoice_4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtchoice_3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtchoice_2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnedit);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtcategory_Id);
            this.Controls.Add(this.txtanswer);
            this.Controls.Add(this.txtchoices);
            this.Controls.Add(this.txtquestion);
            this.Controls.Add(this.txtId);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Admin";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quizquestionsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quizdbDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quizquestionsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quizdbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtquestion;
        private System.Windows.Forms.TextBox txtchoices;
        private System.Windows.Forms.TextBox txtanswer;
        private System.Windows.Forms.TextBox txtcategory_Id;
        private System.Windows.Forms.DataGridView dataGridView1;
        private quizdbDataSet quizdbDataSet;
        private System.Windows.Forms.BindingSource quizquestionsBindingSource;
        private quizdbDataSetTableAdapters.Quiz_questionsTableAdapter quiz_questionsTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnedit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtchoice_2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtchoice_3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtchoice_4;
        private quizdbDataSet2 quizdbDataSet2;
        private System.Windows.Forms.BindingSource quizquestionsBindingSource1;
        private quizdbDataSet2TableAdapters.Quiz_questionsTableAdapter quiz_questionsTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn question;
        private System.Windows.Forms.DataGridViewTextBoxColumn choice_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn choice_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn choice_3;
        private System.Windows.Forms.DataGridViewTextBoxColumn choice_4;
        private System.Windows.Forms.DataGridViewTextBoxColumn answer;
        private System.Windows.Forms.DataGridViewTextBoxColumn category_id;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn questionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn choice1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn choice2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn choice3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn choice4DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn answerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryidDataGridViewTextBoxColumn;
    }
}