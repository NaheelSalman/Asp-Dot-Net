﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidTermVPLAB
{
    public partial class IQuiz : Form
    {
        public IQuiz()
        {
            InitializeComponent();
        }
        string Answer;

        int level = 0;
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        private void button5_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true && Answer == radioButton1.Text && level != 5)
            {
                ScoreBoard.Score+=10;
                StartGame();
            }
            else if (radioButton2.Checked == true && Answer == radioButton2.Text && level != 5)
            {
                ScoreBoard.Score+=10;
                StartGame();
            }
            else if (radioButton3.Checked == true && Answer == radioButton3.Text && level != 5)
            {
                ScoreBoard.Score+=10;
                StartGame();
            }
            else if (radioButton4.Checked == true && Answer == radioButton4.Text && level != 5)
            {
                ScoreBoard.Score+=10;
                StartGame();
            }
        }

        private void IQuiz_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=DESKTOP-B1M1BAQ\SQLEXPRESS;Initial Catalog=quizdb;Integrated Security=True");
            StartGame();
        }
        public void StartGame()
        {
            int id;
            Random rand = new Random();
            id = rand.Next(9, 16);
            con.Open();


            cmd = new SqlCommand("Select question,choice_1,choice_2,choice_3,choice_4,answer from Quiz_questions where Id=@ID", con);
            cmd.Parameters.AddWithValue("@ID", id);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                label1.Text = dr.GetValue(0).ToString();
                radioButton1.Text = dr.GetValue(1).ToString();
                radioButton2.Text = dr.GetValue(2).ToString();
                radioButton3.Text = dr.GetValue(3).ToString();
                radioButton4.Text = dr.GetValue(4).ToString();
                Answer = dr.GetValue(5).ToString();


            }

            con.Close();
            level++;
            if (level == 5)
            {
                ScoreBoard sc = new ScoreBoard();
                sc.Show();
                this.Hide();
                this.Close();
            }

        }
    }
}
