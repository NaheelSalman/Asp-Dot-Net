﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidTermVPLAB
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Admin_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'quizdbDataSet2.Quiz_questions' table. You can move, or remove it, as needed.
            this.quiz_questionsTableAdapter1.Fill(this.quizdbDataSet2.Quiz_questions);
            // TODO: This line of code loads data into the 'quizdbDataSet.Quiz_questions' table. You can move, or remove it, as needed.
            //this.quiz_questionsTableAdapter.Fill(this.quizdbDataSet.Quiz_questions);
            con = new SqlConnection(@"Data Source=DESKTOP-B1M1BAQ\SQLEXPRESS;Initial Catalog=quizdb;Integrated Security=True");
            refreshdata();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        int visible;
        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Hide();
            visible++;
            if (visible % 2 == 0)
            {
                dataGridView1.Show();

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //("'','','',''")
            string query = "insert into Quiz_questions values (" + Convert.ToInt32(txtId.Text) + ",'" + txtquestion.Text + "','" + txtchoices.Text + "','" + txtchoice_2.Text + "','" + txtchoice_3.Text + "','" + txtchoice_4.Text + "','" + txtanswer.Text + "'," + Convert.ToInt32(txtcategory_Id.Text) + ")";
            
            cmd = new SqlCommand(query, con);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Added successfully");
            refreshdata();


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string query = "delete from Quiz_questions where Id = " + Convert.ToInt32(txtId.Text);

            cmd = new SqlCommand(query, con);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            refreshdata();

        }
        private void refreshdata()
        {
            string query = "select * from Quiz_questions";

            cmd = new SqlCommand(query, con);

            con.Open();

            dr = cmd.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Load(dr);

            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            //UPDATE table_name
            //SET column1 = value1, column2 = value2, ...
            //WHERE condition;


           // string query = "insert into Quiz_questions values (" + Convert.ToInt32(txtId.Text) + ",'" + txtquestion.Text + "','" + txtchoices.Text + "','" + txtanswer.Text + "'," + Convert.ToInt32(txtcategory_Id.Text) + ")";

            string query = "update td_Employee set Name = '" + txtquestion.Text + "',Email ='" + txtchoices.Text + "',Designation ='" + txtanswer.Text + "',Skills =" + Convert.ToInt32(txtcategory_Id.Text) + " where id =" + Convert.ToInt32(txtId.Text);

            //string query = "update td_Employee set Name = @Name,Email = @Email,Designation = @Designation,Skills = @Skills,Contact No = @Contact No";
            cmd = new SqlCommand(query, con);

            con.Open();
            try { cmd.ExecuteNonQuery(); }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                MessageBox.Show("Error Occured at Line no 66");
            }
            con.Close();
            MessageBox.Show("Updated successfully");

            refreshdata();
        }

        private void btnBack(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Close();
        }
    }
}
