﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace MidTermVPLAB
{
    public partial class ScoreBoard : Form
    {
        public static int Score;
        public ScoreBoard()
        {
            InitializeComponent();
        }

        private void ScoreBoard_Load(object sender, EventArgs e)
        {
            
            label2.Text = Convert.ToString(Score);
        }
    }
}
